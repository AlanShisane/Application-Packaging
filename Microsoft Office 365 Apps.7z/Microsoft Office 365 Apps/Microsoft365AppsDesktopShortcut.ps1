If(!(Test-Path "$env:Public\Desktop\Excel.lnk"))
{ echo "Non-Compliant" } Else 
{ echo "Compliant" }
Copy-Item -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Excel.lnk" -Destination $env:Public\Desktop\ -Force

If(!(Test-Path "$env:Public\Desktop\Access.lnk"))
{ echo "Non-Compliant" } Else 
{ echo "Compliant" }
Copy-Item -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Access.lnk" -Destination $env:Public\Desktop\ -Force

If(!(Test-Path "$env:Public\Desktop\Word.lnk"))
{ echo "Non-Compliant" } Else 
{ echo "Compliant" }
Copy-Item -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Word.lnk" -Destination $env:Public\Desktop\ -Force

If(!(Test-Path "$env:Public\Desktop\PowerPoint.lnk"))
{ echo "Non-Compliant" } Else 
{ echo "Compliant" }
Copy-Item -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\PowerPoint.lnk" -Destination $env:Public\Desktop\ -Force

If(!(Test-Path "$env:Public\Desktop\Outlook.lnk"))
{ echo "Non-Compliant" } Else 
{ echo "Compliant" }
Copy-Item -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Outlook.lnk" -Destination $env:Public\Desktop\ -Force

If(!(Test-Path "$env:Public\Desktop\Publisher.lnk"))
{ echo "Non-Compliant" } Else 
{ echo "Compliant" }
Copy-Item -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Publisher.lnk" -Destination $env:Public\Desktop\ -Force

If(!(Test-Path "$env:Public\Desktop\OneNote.lnk"))
{ echo "Non-Compliant" } Else 
{ echo "Compliant" }
Copy-Item -Path "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\OneNote.lnk" -Destination $env:Public\Desktop\ -Force
Exit