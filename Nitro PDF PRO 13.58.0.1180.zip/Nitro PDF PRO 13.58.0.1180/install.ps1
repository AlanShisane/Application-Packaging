$PSScriptRoot = Split-Path -Path $MyInvocation.MyCommand.Path
msiexec  /i "$PSScriptRoot\nitro_pro13_x64.msi" "TRANSFORMS=$PSScriptRoot\nitro_pro13_x64.mst" /qn | Out-Null 